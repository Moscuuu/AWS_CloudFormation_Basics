exports.handler = async (event) => {
    console.log('Event:', JSON.stringify(event, null, 2));

    const bucket = event.Records[0].s3.bucket.name;
    const key = event.Records[0].s3.object.key;
    
    console.log(`File uploaded: ${key} to bucket: ${bucket}`);

    // Your processing logic can go here

    return {
        statusCode: 200,
        body: JSON.stringify('File processed successfully!'),
    };
};